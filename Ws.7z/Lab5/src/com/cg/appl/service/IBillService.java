package com.cg.appl.service;

import java.util.List;

import com.cg.appl.dto.BillDetails;
import com.cg.appl.dto.Consumer;
import com.cg.appl.exceptions.BillException;


public interface IBillService {
	public BillDetails calBill(BillDetails bill) throws BillException;
	public int addusers(BillDetails bill) throws BillException;
	
}
