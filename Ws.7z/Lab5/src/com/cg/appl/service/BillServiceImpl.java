package com.cg.appl.service;



import com.cg.appl.dao.BillDao;
import com.cg.appl.dao.BillDaoImpl;
import com.cg.appl.dto.BillDetails;
import com.cg.appl.exceptions.BillException;


public class BillServiceImpl implements IBillService{
	BillDao billservice;
	public BillServiceImpl()
	{
		billservice=new BillDaoImpl();
	}
	@Override
	public BillDetails calBill(BillDetails bill) throws BillException {
		return billservice.calBill(bill);
	}
	@Override
	public int addusers(BillDetails bill) throws BillException {
		return billservice.addusers(bill);
	}

}
