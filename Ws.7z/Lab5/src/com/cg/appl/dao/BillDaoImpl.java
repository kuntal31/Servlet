package com.cg.appl.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import com.cg.appl.dto.BillDetails;
import com.cg.appl.exceptions.BillException;
import com.cg.appl.util.DbUtil;


public class BillDaoImpl implements BillDao{

	@Override
	public BillDetails calBill(BillDetails bill) throws BillException {
		Connection conn=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String fname=null;
		int unit_consumed,netamt;
		conn=DbUtil.obtainConnectiom();	
		String Query="select consumer_name from consumers where consumer_num=?";
		try {
			pst=conn.prepareStatement(Query);
			pst.setInt(1, bill.getConsumer_num());
			rs=pst.executeQuery();
			while(rs.next())
			{
				fname=rs.getString("consumer_name");
				//System.out.println(fname);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		unit_consumed=bill.getLast_reading()-bill.getCur_reading();
		System.out.println(unit_consumed);
		netamt=(int)(unit_consumed*1.15+100);
		System.out.println(netamt);
		bill.setUnitconsumed(unit_consumed);
		bill.setNetamount(netamt);
		bill.setConsumer_name(fname);
		return bill;
	}
public int addusers(BillDetails bill) throws BillException{
	Connection conn=null;
	PreparedStatement pst=null;
	int consid=getConsid();
	int status=0;
		System.out.println("hi");
		try {
			conn=DbUtil.obtainConnectiom();	
			String Query="INSERT INTO BILLDETAILS VALUES(?,?,?,?,?,?)";
			pst=conn.prepareStatement(Query);
			//System.out.println("Insert started");
			pst.setInt(1, consid);
			pst.setInt(2, bill.getConsumer_num());
			pst.setInt(3,bill.getCur_reading());
			pst.setInt(4, bill.getUnitconsumed());
			pst.setInt(5, bill.getNetamount());
			Calendar calendar = Calendar.getInstance();
			java.sql.Date currentdate=new java.sql.Date(calendar.getTime().getTime());
			pst.setDate(6, currentdate);
			
			status=pst.executeUpdate();
			if(status==1)
			{
				System.out.println("Inserted");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
	finally
	{
		try {
			pst.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new BillException("Not Inseted");
		}
	}
		return status;
	
}
public int getConsid()
{
	int consid=0;
	Connection conn=null;
	PreparedStatement pst=null;
	String query="select seq_bill_num.nextval from dual";		
	try { 
		conn=DbUtil.obtainConnectiom();
		pst=conn.prepareStatement(query);
		ResultSet res=pst.executeQuery();
		while(res.next())
		{
			consid=res.getInt(1);
		}
		
	} catch (BillException | SQLException e) {
		e.printStackTrace();
		try {
			throw new BillException("error");
		} catch (BillException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	return consid;
}
}
