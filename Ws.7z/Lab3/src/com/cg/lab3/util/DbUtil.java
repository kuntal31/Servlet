package com.cg.lab3.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.lab3.exception.UserException;


public class DbUtil {
	public static Connection obtainConnectiom() throws UserException
	{
		Connection conn=null;
		InitialContext context;
		try {
			context =new InitialContext();
			DataSource source=(DataSource) context.lookup("java:/OracleDS");
			conn=source.getConnection();
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new UserException("Connection in problem");
		}
		return conn;
}
}
