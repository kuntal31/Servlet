package com.cg.lab3.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.lab3.dto.RegisteredUsers;
import com.cg.lab3.exception.UserException;
import com.cg.lab3.util.DbUtil;

public class RegisteredUsersDaoImpl implements IRegisteredUsersDao
{

	@Override
	public int addUser(RegisteredUsers user) throws UserException {
		Connection conn=null;
		PreparedStatement pst=null;
		int status=0;
		
		try {
			conn=DbUtil.obtainConnectiom();
			String Query="INSERT INTO REGISTEREDUSERS VALUES(?,?,?,?,?,?)";
			pst=conn.prepareStatement(Query);
			pst.setString(1,user.getFirstname());
			pst.setString(2,user.getLastname());
			pst.setString(3,user.getPassword());
			pst.setString(4,String.valueOf(user.getGender()));
			pst.setString(5,user.getSkillset());
			pst.setString(6,user.getCity());
			
			status=pst.executeUpdate();
			if(status==1)
			{
				System.out.println("Added");
			}
			
		} catch (UserException | SQLException e) {
			e.printStackTrace();
			throw new UserException("Not Inserted");
		}
		finally
		{
			try
			{
				pst.close();
				conn.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return status;
	}

	@Override
	public List<RegisteredUsers> showAll() throws UserException {
		Connection conn=null;
		PreparedStatement pst=null;
		List<RegisteredUsers> uList=new ArrayList<>();
		try {
			conn=DbUtil.obtainConnectiom();
			String query="SELECT FIRSTNAME,LASTNAME,PASSWORD,GENDER,SKILLSET,CITY FROM REGISTEREDUSERS";
			pst=conn.prepareStatement(query);
			ResultSet res=pst.executeQuery();
			while(res.next())
			{
				RegisteredUsers u= new RegisteredUsers();			
				u.setFirstname(res.getString("firstname"));
				u.setLastname(res.getString("lastname"));
				u.setPassword(res.getString("password"));
				u.setGender(res.getString("gender").charAt(0));
				u.setSkillset(res.getString("skillset"));
				u.setCity(res.getString("city"));
				uList.add(u);
			}
		} catch (UserException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				pst.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new UserException("Problem in Show");
			}
			
		}
		return uList;
	}
	}

