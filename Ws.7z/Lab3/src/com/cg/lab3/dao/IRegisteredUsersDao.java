package com.cg.lab3.dao;

import java.util.List;

import com.cg.lab3.dto.RegisteredUsers;
import com.cg.lab3.exception.UserException;

public interface IRegisteredUsersDao {
	public int addUser(RegisteredUsers user) throws UserException;
	public List<RegisteredUsers> showAll() throws UserException;
}
