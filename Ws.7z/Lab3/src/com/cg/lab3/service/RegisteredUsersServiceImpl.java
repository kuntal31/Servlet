package com.cg.lab3.service;

import java.util.List;

import com.cg.lab3.dao.IRegisteredUsersDao;
import com.cg.lab3.dao.RegisteredUsersDaoImpl;
import com.cg.lab3.dto.RegisteredUsers;
import com.cg.lab3.exception.UserException;

public class RegisteredUsersServiceImpl implements RegisteredUsersService{
	IRegisteredUsersDao userDao;
	public RegisteredUsersServiceImpl()
	{
		userDao=new RegisteredUsersDaoImpl();
	}
	@Override
	public int addUser(RegisteredUsers user) throws UserException {
		return userDao.addUser(user);
	}

	@Override
	public List<RegisteredUsers> showAll() throws UserException{
		return userDao.showAll();
	}

}
