package com.cg.lab3.exception;

public class UserException extends Exception{

	public UserException() {
		super();
	}
	public UserException(String msg) {
		super(msg);
	}
}
