package com.cg.emp.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;
import com.cg.emp.service.EmployeeServiceImpl;

@WebServlet("*.do")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EmployeeService empservice;

	public EmployeeController() {
		empservice = new EmployeeServiceImpl();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request, response);
	}

	protected void ProcessRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		System.out.println(path); // To check path
		if (path.equals("/employee.do")) {
			RequestDispatcher rs = request.getRequestDispatcher("addemp.jsp");
			rs.forward(request, response);
		}
		if (path.equals("/empadd.do")) {
			Employee emp = new Employee();
			String name = request.getParameter("jname");
			String qualification = request.getParameter("jqual");
			String salary = request.getParameter("jsal");
			emp.setEmpName(name);
			emp.setEmpQualification(qualification);
			emp.setSalary(Double.parseDouble(salary));

			try {
				int empId = empservice.addEmployee(emp);
				System.out.println(empId);
				request.setAttribute("id", empId);
				RequestDispatcher req = request
						.getRequestDispatcher("welcome.jsp");
				req.forward(request, response);
			} catch (EmployeeException e) {
				e.printStackTrace();
			}
		} 
		else if (path.equals("/showall.do")) {
			List<Employee> myList = null;
			try {
				myList = empservice.showAll();
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(myList);
			request.setAttribute("data",myList);
			RequestDispatcher rs=request.getRequestDispatcher("showall.jsp");
			rs.forward(request,response);
		}
		else if(path.equals("/update.do")){
		String data=request.getQueryString();
		String empId=data.substring(3, 7);
		int id=Integer.parseInt(empId);
		Employee eData=empservice.getEmployeeDetails(id);
		request.setAttribute("empdata",eData);
		System.out.println(eData);
		RequestDispatcher rs=request.getRequestDispatcher("updateemp.jsp");
		rs.forward(request,response);
	}
		else if(path.equals("/updatedata.do"))
		{
			List<Employee> mList=new ArrayList<>();
			int id=Integer.parseInt(request.getParameter("id"));
			String name=request.getParameter("fname");
			String qual=request.getParameter("qual");
			Double salary=Double.parseDouble(request.getParameter("sal"));
			Employee emp=new Employee(id,name,qual,salary);
			try {
				if(empservice.updateEmployee(emp))
				{
					System.out.println("data updated");
					mList=empservice.showAll();
					request.setAttribute("data", mList);
					RequestDispatcher req=request.getRequestDispatcher("showall.jsp");
					req.forward(request,response);
				}
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(path.equals("/delete.do"))
		{
			String id=request.getQueryString().substring(3,7);
			int eid=Integer.parseInt(id);
			try
			{
				if(empservice.deleteEmployee(eid))
				{
					System.out.println("Deleted");
				}
			}catch(EmployeeException e)
			{
				e.printStackTrace();
			}
}
}
}
