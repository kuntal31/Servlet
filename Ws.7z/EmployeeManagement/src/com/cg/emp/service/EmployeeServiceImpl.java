package com.cg.emp.service;

import java.util.List;

import com.cg.emp.dao.EmployeeDaoImpl;
import com.cg.emp.dao.IEmployeeDao;
import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
IEmployeeDao empDao;
public EmployeeServiceImpl()
{
	empDao=new EmployeeDaoImpl();
}
	@Override
	public int addEmployee(Employee emp) throws EmployeeException{
		
		return empDao.addEmployee(emp);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException
	{
		return empDao.showAll();
	}
	@Override
	public Employee getEmployeeDetails(int id) {
		return empDao.getEmployeeDetails(id);
	}
	@Override
	public boolean updateEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.updateEmployee(emp);
	}
	@Override
	public boolean deleteEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.deleteEmployee(id);
	}
	

}
