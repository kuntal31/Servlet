package com.cg.emp.service;

import java.util.List;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeeService {
	public int addEmployee(Employee emp) throws EmployeeException;
	public List<Employee> showAll() throws EmployeeException;
	public Employee getEmployeeDetails(int id);
	public boolean updateEmployee(Employee emp) throws EmployeeException;
	public boolean deleteEmployee(int id) throws EmployeeException;
}
