package com.cg.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.DbUtil;

public class EmployeeDaoImpl implements IEmployeeDao {

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		Connection conn=null;
		PreparedStatement pst=null;
		int empId=getEmployee(); //returns method
		int msg=0;
		String Query="INSERT INTO EMPLOYEEMANAGMENT VALUES(?,?,?,?)";
		try
		{
			conn=DbUtil.obtainConnectiom();
			pst=conn.prepareStatement(Query);
			pst.setInt(1,empId);
			pst.setString(2,emp.getEmpName());
			pst.setString(3,emp.getEmpQualification());
			pst.setDouble(4,emp.getSalary());			
			int status=pst.executeUpdate();
			if(status==1)
			{
				msg=empId;
			}
		}
		catch(EmployeeException | SQLException e)
		{
			e.printStackTrace();
		throw new EmployeeException("Not Inserted");
		}
		finally
		{
			try
			{
				pst.close();
				conn.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		return msg;
	}
//ShowAll Method
	@Override
	public List<Employee> showAll() throws EmployeeException {
		Connection conn=null;
		PreparedStatement pst=null;
		List<Employee> myEmp=new ArrayList<>();
		String query="SELECT EMP_ID,EMP_NAME,EMP_QUAL,EMP_SAL FROM EMPLOYEEMANAGMENT ORDER BY EMP_ID";
		try {
			conn=DbUtil.obtainConnectiom();
			pst=conn.prepareStatement(query);
			ResultSet res=pst.executeQuery();
			while(res.next())
			{
				Employee e=new Employee();
				e.setEmpId(res.getInt("emp_id"));
				e.setEmpName(res.getString("emp_name"));
				e.setEmpQualification(res.getString("emp_qual"));
				e.setSalary(res.getDouble("emp_sal"));
				myEmp.add(e);
			}
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				pst.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new EmployeeException("Problem in Show");
			}
			
		}
		return myEmp;
	}
	
	//getEmployeeId
	public int getEmployee()
	{
		int empId=0;
		Connection conn=null;
		PreparedStatement pst=null;
		String query="select empm_id_seq.nextval from dual";		
		try { 
			conn=DbUtil.obtainConnectiom();
			pst=conn.prepareStatement(query);
			ResultSet res=pst.executeQuery();
			while(res.next())
			{
				empId=res.getInt(1);
			}
			
		} catch (EmployeeException | SQLException e) {
			e.printStackTrace();
			try {
				throw new EmployeeException("error");
			} catch (EmployeeException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return empId;
	}
	@Override
	public Employee getEmployeeDetails(int id) {
		Connection conn=null;
		PreparedStatement pst=null;
		Employee emp= new Employee();
		String query="SELECT EMP_ID,EMP_NAME,EMP_QUAL,EMP_SAL FROM EMPLOYEEMANAGMENT WHERE EMP_ID=?";
		try {
			conn=DbUtil.obtainConnectiom();
			pst=conn.prepareStatement(query);
			pst.setInt(1, id);
			ResultSet res=pst.executeQuery();
			while(res.next())
			{
				emp.setEmpId(res.getInt("emp_id"));
				emp.setEmpName(res.getString("emp_name"));
				emp.setEmpQualification(res.getString("emp_qual"));
				emp.setSalary(res.getDouble("emp_sal"));
			}
		} catch (EmployeeException |SQLException e) {
			e.printStackTrace();
		} 
		return emp;
	}
	@Override
	public boolean updateEmployee(Employee emp) throws EmployeeException{
		Connection conn=null;
		PreparedStatement pst=null;
		int rec=0;
		String query="update employeemanagment set emp_name=?,emp_qual=?,emp_sal=? where emp_id=?";
		try {
			conn=DbUtil.obtainConnectiom();
			pst=conn.prepareStatement(query);
			pst.setString(1,emp.getEmpName());
			pst.setString(2,emp.getEmpQualification());
			pst.setDouble(3,emp.getSalary());
			pst.setInt(4,emp.getEmpId());
			rec=pst.executeUpdate();
			if(rec>0)
			{
					return true;
			}
		}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				try {
					pst.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		return false;
	}
	@Override
	public boolean deleteEmployee(int id) throws EmployeeException {
		Connection conn=null;
		PreparedStatement pst=null;
		int rec=0;
		String query="delete from employeemanagment where emp_id=?";
		try {
			conn=DbUtil.obtainConnectiom();
			pst=conn.prepareStatement(query);
			pst.setInt(1, id);
			rec=pst.executeUpdate();
			if(rec>0)
			{
				return true;
			}
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Problem in delete");
		}
		return false;
	}

}
