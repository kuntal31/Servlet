package com.cg.lab3.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.lab3.dto.RegisteredUsers;
import com.cg.lab3.exception.UserException;
import com.cg.lab3.service.RegisteredUsersService;
import com.cg.lab3.service.RegisteredUsersServiceImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RegisteredUsersService userservice;
       
    public FrontController() {
		userservice = new RegisteredUsersServiceImpl();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProcessRequest(request, response);
	}
	protected void ProcessRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		System.out.println(path); // To check path
		if (path.equals("/user.do")) {
			//response.sendRedirect("Adduser.html");
			RequestDispatcher req = request.getRequestDispatcher("Adduser.html");
			req.forward(request, response);
		}
			if (path.equals("/useradd.do")) {
				String fname = request.getParameter("fname");
				String lname = request.getParameter("lname");
				String password = request.getParameter("pwd");
				char gender1=request.getParameter("gender").charAt(0);
				String skillset=null;
				String arr[]=request.getParameterValues("skill");
				for(String s: arr){
					skillset=skillset+","+s;
					}			
				String city1=request.getParameter("city");
				RegisteredUsers user= new RegisteredUsers(fname,lname,password,gender1,skillset,city1);
				/*user.setFirstname(fname);
				user.setLastname(lname);
				user.setPassword(password);
				user.setGender(gender1);
				user.setSkillset(skillset);
				user.setCity(city1);*/
				
				try {
					int u = userservice.addUser(user);
					System.out.println(u);
					//response.sendRedirect("welcome.html");
					RequestDispatcher req = request.getRequestDispatcher("showall.jsp");
					req.forward(request, response);
				} catch (UserException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				else if (path.equals("/showall.do")) {
					List<RegisteredUsers> myList = null;
					try {
						myList = userservice.showAll();
						//System.out.println(myList);
						request.setAttribute("data",myList);
						RequestDispatcher req=request.getRequestDispatcher("showall.jsp");
						req.forward(request,response);
					} catch (UserException e) {
						
						e.printStackTrace();
					
				}
				
	}
	}
	}

	
	

